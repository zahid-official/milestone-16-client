export interface BorrowData {
  book: {
    title: string;
    isbn: string;
  };
  totalQuantity: number;
}
